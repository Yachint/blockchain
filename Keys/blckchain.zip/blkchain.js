const sha256 = require('sha256');

function blkchain(){
    this.chain = [];
    this.pendingtransactions = [];
};

blkchain.prototype.creat_new_blk = (nonce, prev_hash, hash) => {

    const new_blk = {
        index : this.chain.length + 1,
        timestamp : Date.now(),
        nonce: nonce,
        hash = hash,
        prev_hash : prev_hash,
        transactions : this.pendingtransactions
    };

    this.pendingtransactions = [];
    this.chain.push(new_blk);

    return new_blk;
}

blkchain.prototype.getLastBlock = () => {
    return this.chain[this.chain.length - 1];
}

blkchain.prototype.hashBlock = (prev_hash, curr_blk_data, nonce) => {
    const data = ''+prev_hash+curr_blk_data+nonce;
    const hash = sha256(data);
    return hash;

};

blkchain.prototype.POW = (prev_hash, curr_blk_data) => {
    let nonce = 0;
    let hash = this.hashBlock(prev_hash, curr_blk_data, nonce);
    while(hash.substring(0,4) != '0000'){
        nonce++;
        hash=this.hashBlock(prev_hash, curr_blk_data, nonce);
            console.log(hash);
    }
    return nonce;
}

blkchain.prototype.createNewTransaction = (amount, sender, recepeint) => {

    const new_trans = {
        amount : amount,
        sender : sender,
        recepeint : recepeint
    };
    this.pendingtransactions.push(new_trans);
    return this.getLastBlock()['index'] + 1;
};



module.exports = blkchain;