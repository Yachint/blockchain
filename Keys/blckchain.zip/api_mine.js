var express = require('express')
var app = express();
const bodyparser = require('body-parser');
const blockchain = require('./blkchain');
const bitcoin = new blockchain();

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:false}));
const uuid = require('uuid/v1');
const nodeAdress = uuid().split('-').join('');


app.get('/', function(req,res){
    res.send('Hello World');
});

app.get('/blockchain',function(req,res){
    res.send(bitcoin);
});

app.post('/transaction',function(req,res){
    const blockindex = bitcoin.createNewTransaction(req.body.amount,
        req.body.sender, req.body.recepeint);
    res.send('Processing Transaction in block :'+blockindex+'....');

})

app.get('/mine',function(req,res){
    const lastBlock = bitcoin.getLastBlock();
    const prev_hash = lastBlock['hash'];

    const curr_blk_data = {
        transactions : bitcoin.pendingtransactions,
        index : lastBlock['index'] + 1
    }

    const nonce = bitcoin.POW(prev_hash, curr_blk_data);
    const blockHash = bitcoin.hashBlock(prev_hash, curr_blk_data, nonce);
    bitcoin.createNewTransaction(12.5,'00',nodeAdress);
    const newBlock = bitcoin.creat_new_blk(nonce, prev_hash, blockHash);

    res.json({
        note: "New Block mined Successfully",
        block : newBlock
    });
});


app.listen(8080, function(){
    console.log("Sever Started at port 8000...");

});